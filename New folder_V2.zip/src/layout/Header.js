import React, { Component} from 'react';
import { connect } from 'react-redux'
import { Link } from "react-router-dom";
import { loginAction } from '../redux-Store/loginReducer';


class Header extends Component {
    render() {
        return (
            <React.Fragment>
                <header className="header header--compressed">
                    <div className="header-bar container">
                        <span className="header-bar__logo">
                            <span className="icon-cisco"></span>
                        </span>
                        <div className="header-bar__main">
                            <div className="header-heading">
                                <h1 className="page-title">React Basic Setup</h1>
                            </div>
                        </div>
                        <div className="header-toolbar hidden-xs hidden-sm hidden-md hidden-lg">
                            <div>
                                <span><Link to="/home">Home</Link></span>
                                <span className="base-margin-left">
                                    {this.props.loginActive &&
                                        <button onClick={this.props.logOutMe} data-balloon="Log out" data-balloon-pos="down" className="btn btn--icon btn--small btn--success"><span className="icon-sign-out"></span></button>
                                    }
                                    {!this.props.loginActive &&
                                        <button  data-balloon="Log In" data-balloon-pos="down" className="btn btn--icon btn--small btn--negative"><span className="icon-forced-sign-in"></span></button>
                                    }
                                </span>
                                <div className="dropdown dropdown--left base-margin-left">
                                    <div className="form-group form-group--inline input--icon">
                                        <div className="form-group__text">
                                            <input type="search" placeholder="Search Kit" style={{width:'320px'}} />
                                            <button type="button" className="link">
                                                <span className="icon-search"></span>
                                            </button>
                                        </div>
                                    </div>
                                    <div id="search-results" className="dropdown__menu" style={{top: '100%', width: '100%', display: 'block', overflow: 'hidden auto', maxHeight: '369px'}}>
                                        <a className="no-link">Start Typing for Results</a>
                                    </div>
                                </div>
                            </div>
                        </div>                    
                    </div>
                </header>
            </React.Fragment >
        );
    }
}

const mapStateToProps = (state) => ({
    loginActive: state.loginR.active
})

const mapDispatchToProps = (dispatch, ownProps) =>({    
    logOutMe: () => dispatch(loginAction.logOut(ownProps))
})

export default connect(mapStateToProps, mapDispatchToProps)(Header);