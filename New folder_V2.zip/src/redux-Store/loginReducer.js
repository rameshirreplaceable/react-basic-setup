import { delay } from "q";
import Axios from "axios";
import { serviceHandle } from "../configuration/serviceHandle";
import {Toastify} from '../configuration/toastify';
// ////////////////////////////////////////////////////////////
// //////////////////Login Constance ////////////////////////////
// ////////////////////////////////////////////////////////////
export const loginConstants = {
    LOGIN: 'LOGIN',
    LOGOUT: 'LOGOUT'
}

// ////////////////////////////////////////////////////////////
// //////////////////Login Action ////////////////////////////
// ////////////////////////////////////////////////////////////
export const loginAction = {
    login,
    logOut
}
function login(username, password, ownProps) {
    return (dispatch) => {
        if (username === 'ramesh@cisco.com' && password === 'ramesh'){
            dispatch({ type: 'LOGIN' });
            Toastify.ToastifyMe({ type: "success", html: `<div class="alert__message">Login success</div>`, containerId: 'success'});
            ownProps.history.push('/')
        }else{
            Toastify.ToastifyMe({ type: "error", html: `Invalied Username/Password...!`, containerId: 'error' });
        }
    }
}
function logOut(ownProps) {
    return (dispatch) => {
        dispatch({ type: 'LOGOUT' });
        Toastify.ToastifyMe({ type: "error", html: `Please Login Agian...!`, containerId: 'error' });

    }
}

// ////////////////////////////////////////////////////////////
// //////////////////Login Reducer ////////////////////////////
// ////////////////////////////////////////////////////////////
export const loginstatus = {
    active: false,
    status: 'inactive'
}
const loginReducer = (state = loginstatus, action) => {
    switch (action.type) {
        case loginConstants.LOGIN:
            return { active: true, status: 'active' }
        case loginConstants.LOGOUT:
            return { active: false, status: 'inactive' }
        default:
            return state
    }
}
export default loginReducer;