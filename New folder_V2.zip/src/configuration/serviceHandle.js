
function handleError(error){
    console.log(error.response);
    if (error.response && error.response.status){
        let res = error.response;
        switch (res.status) {
            case 404:
                console.log("404: Request Not found 😢");
                break;
            case 401:
                console.log("401: Internal server error 😢"); // We can set custom error msg based on service response error...
                break;
            default:
                break;
        }
    }else{
        console.log(error);
        console.log("Internet connection Lost 😈");
    }
}

export const serviceHandle = {
    handleError
}