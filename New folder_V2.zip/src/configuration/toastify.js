import React from 'react'
import { toast } from 'react-toastify';
export const Toastify = {
    ToastifyMe
}
function ToastifyMe({ type = 'success', html = 'Success', position = 'TOP_RIGHT', containerId = "success" }) {
    switch (type) {
        case 'success':
            toast.success(<div dangerouslySetInnerHTML={{ __html: html }}></div>, {
                position: toast.POSITION[position],
                containerId: containerId
            });
            break;
        case 'error':
            toast.error(html, {
                position: toast.POSITION[position],
                containerId: containerId
            });
            break;
        case 'warn':
            toast.warn(html, {
                position: toast.POSITION[position],
                containerId: containerId
            });
            break;
        case 'info':
            toast.info(html, {
                position: toast.POSITION[position],
                containerId: containerId
            });
            break;

        default:
            break;
    }
}