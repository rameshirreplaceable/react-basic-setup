import React from 'react';
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

// Auth
import PrivateRoute from './auth/PrivateRoute';

// Layout
import Header from './layout/Header';
// Pages
import Home from './pages/Home';
import Login from './pages/Login';

class App extends React.Component {
  render() {
    return (
      <React.Fragment>
      <main>
        <Router>
          <Header></Header>
          <div className="content">
            <div className="container ptb20">
              <div>
                <Route component={Login}></Route>{/** For Unmatched URl redirecting... to Home */}
                <Route path="/login" component={Login}></Route>
                <PrivateRoute path="/" exact component={Home}></PrivateRoute>
                <PrivateRoute path="/home" exact component={Home}></PrivateRoute>
              </div>
            </div>
          </div>
        </Router>
      </main>
      <ToastContainer />
      </React.Fragment>
    );
  }
}
export default App;
