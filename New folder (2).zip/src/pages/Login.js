import React, { useState, useReducer, useEffect } from 'react';
import { connect } from 'react-redux';
import { loginAction } from '../redux-Store/loginReducer';


const mapStateToProps = (state) => ({
    active: state.loginR.active
})
const mapDispatchToProps = (dispatch, ownProps)=>({
    login: (username, password) => dispatch(loginAction.login(username, password, ownProps)) // Pass with ownProps
    // login: loginAction.login // With out passing ownProps
})
export default connect(mapStateToProps, mapDispatchToProps)(Login);
function Login(props) {
    const userName = useFormInput('ramesh@cisco.com');
    const password = useFormInput('ramesh');

    function validateUser() {
        if (userName.value && password.value) {
            props.login(userName.value, password.value);
        }
    }    
    return (
        <div>
            <div className={`modal ${props.active? 'hide': ''}`} style={{ background: '#3333332b' }}>
                <div className="modal__dialog animated zoomIn " style={{ marginTop: '10vm' }}>
                    <div className="modal__content">
                        <div className="modal__header">
                            <div className="icon-cisco text-blue text-huge half-margin-bottom"></div>
                            <h1 className="modal__title">React Basic Setup </h1>
                        </div>

                        <div className="modal__body">
                            <div className="row">
                                <div className="col-md-6 ">
                                    <div className={`form-group ${userName.value == '' ? 'form-group--error' : ''}`}>
                                        <div className="form-group__text">
                                            <input type="text" {...userName} required />
                                            <label>User Name</label>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-md-6 ">
                                    <div className={`form-group ${password.value == '' ? 'form-group--error' : ''}`}>
                                        <div className="form-group__text">
                                            <input type="password" {...password} required />
                                            <label>Password</label>
                                        </div>
                                    </div>
                                </div>
                               
                            </div>
                        </div>

                        <div className="modal__footer">
                            <button className="btn btn--primary" onClick={validateUser} disabled={!(userName.value && password.value)}>Log In</button>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    );
}
function useFormInput(initialState) {
    const [value, setvalue] = useState(initialState);
    function handleChange(e) {
        setvalue(e.target.value);
    }
    return {
        value,
        onChange: handleChange
    }
}