import { toast } from 'react-toastify';
import { delay } from "q";
import Axios from "axios";
import { serviceHandle } from "../configuration/serviceHandle";

// ////////////////////////////////////////////////////////////
// //////////////////Login Constance ////////////////////////////
// ////////////////////////////////////////////////////////////
export const loginConstants = {
    LOGIN: 'LOGIN',
    LOGOUT: 'LOGOUT'
}

// ////////////////////////////////////////////////////////////
// //////////////////Login Action ////////////////////////////
// ////////////////////////////////////////////////////////////
export const loginAction = {
    login,
    logOut
}
function login(username, password, ownProps) {
    return (dispatch) => {
        if (username === 'ramesh@cisco.com' && password === 'ramesh'){
            dispatch({ type: 'LOGIN' });
            toast.success("Login Success!", {
                position: toast.POSITION.TOP_RIGHT
            });
            ownProps.history.push('/')
        }
    }
}
function logOut(ownProps) {
    return (dispatch) => {
        dispatch({ type: 'LOGOUT' });
        toast.error("Please Login Agian...!", {
            position: toast.POSITION.TOP_RIGHT
        });
    }
}

// ////////////////////////////////////////////////////////////
// //////////////////Login Reducer ////////////////////////////
// ////////////////////////////////////////////////////////////
export const loginstatus = {
    active: false,
    status: 'inactive'
}
const loginReducer = (state = loginstatus, action) => {
    switch (action.type) {
        case loginConstants.LOGIN:
            return { active: true, status: 'active' }
        case loginConstants.LOGOUT:
            return { active: false, status: 'inactive' }
        default:
            return state
    }
}
export default loginReducer;