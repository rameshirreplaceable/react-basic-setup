import { createStore, combineReducers, applyMiddleware, compose  } from 'redux'
import thunk from 'redux-thunk';

/**
 * All Reducer
 */
import loginReducer from './loginReducer';


const rootReducer  = combineReducers({
    loginR: loginReducer
})


/**
 * Main Redux Store section
 */
export const store = createStore(
    rootReducer,
    compose(
        applyMiddleware(thunk),
        window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__()
    )
);
